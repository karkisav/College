#ifndef SALARY_H
#define SALARY_H

void generate_salary_slip(int employee_id);
float calculate_deduction(int employee_id);

#endif