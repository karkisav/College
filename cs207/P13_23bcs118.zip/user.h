#ifndef USER_H
#define USER_H

void employee_menu();
void manager_menu();
void admin_menu();

#endif